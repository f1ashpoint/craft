"use strict";(()=>{var e={};e.id=672,e.ids=[672],e.modules={5890:e=>{e.exports=require("better-sqlite3")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},2048:e=>{e.exports=require("fs")},5315:e=>{e.exports=require("path")},6250:(e,E,T)=>{T.r(E),T.d(E,{originalPathname:()=>p,patchFetch:()=>U,requestAsyncStorage:()=>d,routeModule:()=>o,serverHooks:()=>u,staticGenerationAsyncStorage:()=>l});var t={};T.r(t),T.d(t,{POST:()=>L});var r=T(9303),i=T(8716),a=T(3131),s=T(7543),N=T(1402),n=T(9178);let L=(0,N.pr)(async e=>{let E=e.headers.get("x-forwarded-for")?.split(",")[0]?.trim()||"local";(0,n.Kp)(E);let T=s.Ryn({email:s.Z_8().email(),password:s.Z_8().min(1).max(200)}).parse(await e.json()),t=(0,n.x4)(T.email,T.password);if(!t)throw new N.oo(401,"Email or password is incorrect.");return(0,N.AV)({ok:!0},200,{"Set-Cookie":(0,n.Sp)((0,n.B3)(t))})}),o=new r.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/admin/login/route",pathname:"/api/admin/login",filename:"route",bundlePath:"app/api/admin/login/route"},resolvedPagePath:"/home/claude/csc/app/api/admin/login/route.ts",nextConfigOutput:"standalone",userland:t}),{requestAsyncStorage:d,staticGenerationAsyncStorage:l,serverHooks:u}=o,p="/api/admin/login/route";function U(){return(0,a.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:l})}},9178:(e,E,T)=>{T.d(E,{B3:()=>L,Jg:()=>o,Kp:()=>p,Sp:()=>d,gf:()=>s,kF:()=>l,x4:()=>U});var t=T(4770),r=T.n(t),i=T(3652),a=T(1402);let s="csc_admin";function N(){let e=process.env.SESSION_SECRET;if(!e||e.length<32)throw Error("SESSION_SECRET must be set to at least 32 characters.");return e}let n=e=>Buffer.from(e).toString("base64url");function L(e,E=Date.now()){let T=n(JSON.stringify({id:e,exp:E+432e5})),t=r().createHmac("sha256",N()).update(T).digest("base64url");return`${T}.${t}`}function o(e,E=Date.now()){if(!e)return null;let[T,t]=e.split(".");if(!T||!t)return null;let a=r().createHmac("sha256",N()).update(T).digest("base64url"),s=Buffer.from(t),n=Buffer.from(a);if(s.length!==n.length||!r().timingSafeEqual(s,n))return null;try{let e=JSON.parse(Buffer.from(T,"base64url").toString());if("number"!=typeof e.id||"number"!=typeof e.exp||e.exp<E)return null;return(0,i.z)().prepare("SELECT id FROM admins WHERE id = ?").get(e.id)?{id:e.id}:null}catch{return null}}function d(e,E=!1){return`${s}=${E?"":e}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${E?0:43200}; Secure`}function l(e){let E=o((0,a.vQ)(e,s));if(!E)throw new a.oo(401,"Please sign in to continue.");if(!["GET","HEAD"].includes(e.method)){let E=e.headers.get("origin"),T=e.headers.get("host");if(E&&T&&new URL(E).host!==T)throw new a.oo(403,"Cross-origin request blocked.")}return E}let u=new Map;function p(e,E=Date.now()){let T=u.get(e);if(!T||T.reset<E){u.set(e,{n:1,reset:E+9e5});return}if(++T.n>8)throw new a.oo(429,"Too many sign-in attempts. Please wait 15 minutes.")}function U(e,E){let T=(0,i.z)().prepare("SELECT id, password_hash FROM admins WHERE email = ?").get(e.trim().toLowerCase()),t=function(e,E){let[T,t,i]=E.split("$");if("scrypt"!==T||!t||!i)return!1;let a=r().scryptSync(e,t,64),s=Buffer.from(i,"hex");return s.length===a.length&&r().timingSafeEqual(s,a)}(E,T?.password_hash??"scrypt$00$00");return T&&t?T.id:null}},3652:(e,E,T)=>{T.d(E,{z:()=>d});var t=T(5890),r=T.n(t),i=T(2048),a=T.n(i),s=T(5315),N=T.n(s);let n=`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, blurb TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  price_paise INTEGER NOT NULL CHECK (price_paise >= 0),
  gst_rate REAL, hsn TEXT NOT NULL DEFAULT '',
  lead_time_days INTEGER CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  engraving_enabled INTEGER NOT NULL DEFAULT 0, engraving_max INTEGER NOT NULL DEFAULT 20, engraving_fee_paise INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS product_categories (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, category_id)
);
CREATE TABLE IF NOT EXISTS variants (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  label TEXT NOT NULL, sku TEXT NOT NULL DEFAULT '', price_paise INTEGER CHECK (price_paise IS NULL OR price_paise >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0), sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL, alt TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_addons (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  addon_product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, addon_product_id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY, token TEXT UNIQUE NOT NULL, number TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',
  email TEXT NOT NULL, phone TEXT NOT NULL, name TEXT NOT NULL,
  ship_line1 TEXT NOT NULL, ship_line2 TEXT NOT NULL DEFAULT '', ship_city TEXT NOT NULL, ship_state TEXT NOT NULL,
  ship_pincode TEXT NOT NULL, ship_country TEXT NOT NULL DEFAULT 'India',
  items_total_paise INTEGER NOT NULL, discount_paise INTEGER NOT NULL DEFAULT 0, shipping_paise INTEGER NOT NULL,
  total_paise INTEGER NOT NULL, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  shipping_taxable_paise INTEGER NOT NULL DEFAULT 0, shipping_tax_paise INTEGER NOT NULL DEFAULT 0, shipping_gst_rate REAL NOT NULL DEFAULT 0,
  intra_state INTEGER NOT NULL DEFAULT 1,
  loyalty_enrolled INTEGER NOT NULL DEFAULT 0, points_redeemed INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0,
  payment_provider TEXT NOT NULL DEFAULT '', payment_ref TEXT NOT NULL DEFAULT '',
  shipping_provider TEXT NOT NULL DEFAULT '', awb TEXT NOT NULL DEFAULT '', tracking_url TEXT NOT NULL DEFAULT '',
  dispatch_by TEXT, visitor_id TEXT, notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')), paid_at TEXT, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, variant_id INTEGER, name TEXT NOT NULL, variant_label TEXT NOT NULL DEFAULT '', hsn TEXT NOT NULL DEFAULT '',
  gst_rate REAL NOT NULL, qty INTEGER NOT NULL, unit_paise INTEGER NOT NULL, gross_paise INTEGER NOT NULL,
  discount_paise INTEGER NOT NULL DEFAULT 0, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  engraving TEXT NOT NULL DEFAULT '', made_to_order INTEGER NOT NULL DEFAULT 0, stock_reserved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), number TEXT UNIQUE NOT NULL,
  issued_at TEXT NOT NULL, seller_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoice_counters (fy TEXT PRIMARY KEY, last INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS loyalty_members (email TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', points INTEGER NOT NULL DEFAULT 0, enrolled_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS loyalty_ledger (id INTEGER PRIMARY KEY, email TEXT NOT NULL, order_id INTEGER, delta INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, visitor_id TEXT NOT NULL, product_id INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('view','cart','purchase')), created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_events_visitor ON events(visitor_id);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
`,L=[{slug:"clay",name:"Air-Dry Clay & Polymer Clay",blurb:"Charms, trinket dishes and small sculpted pieces, shaped by hand."},{slug:"fiber-textile",name:"Fiber & Textile Art",blurb:"Chenille, thread and cloth worked into soft, tactile things."},{slug:"ceramics",name:"Handmade Ceramics",blurb:"Wheel-thrown and hand-built mugs, bowls and vases."},{slug:"home-decor",name:"Aesthetic Home Decor",blurb:"Quiet, colourful objects for shelves, walls and windowsills."},{slug:"accessories",name:"Personal Accessories",blurb:"Earrings, necklaces and little things to wear every day."},{slug:"wedding-events",name:"Wedding & Events",blurb:"Favours, table pieces and keepsakes made in batches."}],o=globalThis;function d(){if(o.__csc_db)return o.__csc_db;let e=process.env.DATABASE_PATH||"./data/store.db";":memory:"!==e&&a().mkdirSync(N().dirname(N().resolve(e)),{recursive:!0});let E=new(r())(e);E.pragma("journal_mode = WAL"),E.pragma("foreign_keys = ON"),E.exec(n);let T=E.prepare("INSERT OR IGNORE INTO categories (slug, name, blurb, sort) VALUES (?,?,?,?)");return L.forEach((e,E)=>T.run(e.slug,e.name,e.blurb,E)),o.__csc_db=E,E}},1402:(e,E,T)=>{T.d(E,{AV:()=>a,oo:()=>i,pr:()=>s,vQ:()=>N});var t=T(9489),r=T(5462);class i extends Error{constructor(e,E,T){super(E),this.status=e,this.fields=T}}function a(e,E=200,T={}){return new Response(JSON.stringify(e),{status:E,headers:{"Content-Type":"application/json","Cache-Control":"no-store",...T}})}function s(e){return async(E,T)=>{try{return await e(E,T)}catch(e){if(e instanceof i)return a({error:e.message,fields:e.fields},e.status);if(e instanceof Error&&"SyntaxError"===e.name)return a({error:"The request was not valid JSON."},400);if(e instanceof t.j){let E={};for(let T of e.issues)E[T.path.join(".")||"_"]=T.message;return a({error:"Please check the highlighted fields.",fields:E},400)}return(0,r.H)("unhandled api error",e,{url:E.url,method:E.method}),a({error:"Something went wrong on our side. Please try again in a moment."},500)}}}function N(e,E){for(let T of(e.headers.get("cookie")||"").split(/;\s*/)){let e=T.indexOf("=");if(e>0&&T.slice(0,e)===E)return decodeURIComponent(T.slice(e+1))}}},5462:(e,E,T)=>{T.d(E,{H:()=>t});let t=(e,E,T={})=>(function(e,E,T={}){if(process.env.VITEST)return;let t=JSON.stringify({t:new Date().toISOString(),level:e,msg:E,...T});("error"===e?console.error:console.log)(t)})("error",e,{...T,err:E instanceof Error?{message:E.message,stack:E.stack}:String(E)})},9303:(e,E,T)=>{e.exports=T(517)}};var E=require("../../../../webpack-runtime.js");E.C(e);var T=e=>E(E.s=e),t=E.X(0,[948,489,543],()=>T(6250));module.exports=t})();