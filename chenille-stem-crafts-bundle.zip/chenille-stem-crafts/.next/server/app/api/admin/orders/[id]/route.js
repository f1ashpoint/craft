"use strict";(()=>{var e={};e.id=319,e.ids=[319],e.modules={5890:e=>{e.exports=require("better-sqlite3")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},2048:e=>{e.exports=require("fs")},5315:e=>{e.exports=require("path")},2356:(e,t,E)=>{E.r(t),E.d(t,{originalPathname:()=>U,patchFetch:()=>O,requestAsyncStorage:()=>u,routeModule:()=>l,serverHooks:()=>c,staticGenerationAsyncStorage:()=>p});var r={};E.r(r),E.d(r,{PATCH:()=>d});var T=E(9303),i=E(8716),a=E(3131),s=E(7543),n=E(1402),N=E(9178),o=E(3652);let L=s.Ryn({status:s.KmV(["paid","shipped","delivered","cancelled"]).optional(),awb:s.Z_8().trim().max(60).optional(),trackingUrl:s.Z_8().trim().url().max(300).or(s.i0J("")).optional()}),d=(0,n.pr)(async(e,t)=>{(0,N.kF)(e);let E=Number(t?.params?.id),r=L.parse(await e.json()),T=(0,o.z)().prepare("SELECT status FROM orders WHERE id=?").get(E);if(!T)throw new n.oo(404,"Order not found.");if(r.status&&["pending_payment","expired","payment_failed"].includes(T.status))throw new n.oo(409,"This order has not been paid, so its status cannot be changed.");return(0,o.z)().prepare("UPDATE orders SET status=COALESCE(?,status), awb=COALESCE(?,awb), tracking_url=COALESCE(?,tracking_url) WHERE id=?").run(r.status??null,r.awb??null,r.trackingUrl??null,E),(0,n.AV)({ok:!0})}),l=new T.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/admin/orders/[id]/route",pathname:"/api/admin/orders/[id]",filename:"route",bundlePath:"app/api/admin/orders/[id]/route"},resolvedPagePath:"/home/claude/csc/app/api/admin/orders/[id]/route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:u,staticGenerationAsyncStorage:p,serverHooks:c}=l,U="/api/admin/orders/[id]/route";function O(){return(0,a.patchFetch)({serverHooks:c,staticGenerationAsyncStorage:p})}},9178:(e,t,E)=>{E.d(t,{B3:()=>o,Jg:()=>L,Kp:()=>p,Sp:()=>d,gf:()=>s,kF:()=>l,x4:()=>c});var r=E(4770),T=E.n(r),i=E(3652),a=E(1402);let s="csc_admin";function n(){let e=process.env.SESSION_SECRET;if(!e||e.length<32)throw Error("SESSION_SECRET must be set to at least 32 characters.");return e}let N=e=>Buffer.from(e).toString("base64url");function o(e,t=Date.now()){let E=N(JSON.stringify({id:e,exp:t+432e5})),r=T().createHmac("sha256",n()).update(E).digest("base64url");return`${E}.${r}`}function L(e,t=Date.now()){if(!e)return null;let[E,r]=e.split(".");if(!E||!r)return null;let a=T().createHmac("sha256",n()).update(E).digest("base64url"),s=Buffer.from(r),N=Buffer.from(a);if(s.length!==N.length||!T().timingSafeEqual(s,N))return null;try{let e=JSON.parse(Buffer.from(E,"base64url").toString());if("number"!=typeof e.id||"number"!=typeof e.exp||e.exp<t)return null;return(0,i.z)().prepare("SELECT id FROM admins WHERE id = ?").get(e.id)?{id:e.id}:null}catch{return null}}function d(e,t=!1){return`${s}=${t?"":e}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${t?0:43200}; Secure`}function l(e){let t=L((0,a.vQ)(e,s));if(!t)throw new a.oo(401,"Please sign in to continue.");if(!["GET","HEAD"].includes(e.method)){let t=e.headers.get("origin"),E=e.headers.get("host");if(t&&E&&new URL(t).host!==E)throw new a.oo(403,"Cross-origin request blocked.")}return t}let u=new Map;function p(e,t=Date.now()){let E=u.get(e);if(!E||E.reset<t){u.set(e,{n:1,reset:t+9e5});return}if(++E.n>8)throw new a.oo(429,"Too many sign-in attempts. Please wait 15 minutes.")}function c(e,t){let E=(0,i.z)().prepare("SELECT id, password_hash FROM admins WHERE email = ?").get(e.trim().toLowerCase()),r=function(e,t){let[E,r,i]=t.split("$");if("scrypt"!==E||!r||!i)return!1;let a=T().scryptSync(e,r,64),s=Buffer.from(i,"hex");return s.length===a.length&&T().timingSafeEqual(s,a)}(t,E?.password_hash??"scrypt$00$00");return E&&r?E.id:null}},3652:(e,t,E)=>{E.d(t,{z:()=>d});var r=E(5890),T=E.n(r),i=E(2048),a=E.n(i),s=E(5315),n=E.n(s);let N=`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, blurb TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  price_paise INTEGER NOT NULL CHECK (price_paise >= 0),
  gst_rate REAL, hsn TEXT NOT NULL DEFAULT '',
  lead_time_days INTEGER CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  engraving_enabled INTEGER NOT NULL DEFAULT 0, engraving_max INTEGER NOT NULL DEFAULT 20, engraving_fee_paise INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS product_categories (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, category_id)
);
CREATE TABLE IF NOT EXISTS variants (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  label TEXT NOT NULL, sku TEXT NOT NULL DEFAULT '', price_paise INTEGER CHECK (price_paise IS NULL OR price_paise >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0), sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL, alt TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_addons (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  addon_product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, addon_product_id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY, token TEXT UNIQUE NOT NULL, number TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',
  email TEXT NOT NULL, phone TEXT NOT NULL, name TEXT NOT NULL,
  ship_line1 TEXT NOT NULL, ship_line2 TEXT NOT NULL DEFAULT '', ship_city TEXT NOT NULL, ship_state TEXT NOT NULL,
  ship_pincode TEXT NOT NULL, ship_country TEXT NOT NULL DEFAULT 'India',
  items_total_paise INTEGER NOT NULL, discount_paise INTEGER NOT NULL DEFAULT 0, shipping_paise INTEGER NOT NULL,
  total_paise INTEGER NOT NULL, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  shipping_taxable_paise INTEGER NOT NULL DEFAULT 0, shipping_tax_paise INTEGER NOT NULL DEFAULT 0, shipping_gst_rate REAL NOT NULL DEFAULT 0,
  intra_state INTEGER NOT NULL DEFAULT 1,
  loyalty_enrolled INTEGER NOT NULL DEFAULT 0, points_redeemed INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0,
  payment_provider TEXT NOT NULL DEFAULT '', payment_ref TEXT NOT NULL DEFAULT '',
  shipping_provider TEXT NOT NULL DEFAULT '', awb TEXT NOT NULL DEFAULT '', tracking_url TEXT NOT NULL DEFAULT '',
  dispatch_by TEXT, visitor_id TEXT, notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')), paid_at TEXT, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, variant_id INTEGER, name TEXT NOT NULL, variant_label TEXT NOT NULL DEFAULT '', hsn TEXT NOT NULL DEFAULT '',
  gst_rate REAL NOT NULL, qty INTEGER NOT NULL, unit_paise INTEGER NOT NULL, gross_paise INTEGER NOT NULL,
  discount_paise INTEGER NOT NULL DEFAULT 0, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  engraving TEXT NOT NULL DEFAULT '', made_to_order INTEGER NOT NULL DEFAULT 0, stock_reserved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), number TEXT UNIQUE NOT NULL,
  issued_at TEXT NOT NULL, seller_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoice_counters (fy TEXT PRIMARY KEY, last INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS loyalty_members (email TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', points INTEGER NOT NULL DEFAULT 0, enrolled_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS loyalty_ledger (id INTEGER PRIMARY KEY, email TEXT NOT NULL, order_id INTEGER, delta INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, visitor_id TEXT NOT NULL, product_id INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('view','cart','purchase')), created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_events_visitor ON events(visitor_id);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
`,o=[{slug:"clay",name:"Air-Dry Clay & Polymer Clay",blurb:"Charms, trinket dishes and small sculpted pieces, shaped by hand."},{slug:"fiber-textile",name:"Fiber & Textile Art",blurb:"Chenille, thread and cloth worked into soft, tactile things."},{slug:"ceramics",name:"Handmade Ceramics",blurb:"Wheel-thrown and hand-built mugs, bowls and vases."},{slug:"home-decor",name:"Aesthetic Home Decor",blurb:"Quiet, colourful objects for shelves, walls and windowsills."},{slug:"accessories",name:"Personal Accessories",blurb:"Earrings, necklaces and little things to wear every day."},{slug:"wedding-events",name:"Wedding & Events",blurb:"Favours, table pieces and keepsakes made in batches."}],L=globalThis;function d(){if(L.__csc_db)return L.__csc_db;let e=process.env.DATABASE_PATH||"./data/store.db";":memory:"!==e&&a().mkdirSync(n().dirname(n().resolve(e)),{recursive:!0});let t=new(T())(e);t.pragma("journal_mode = WAL"),t.pragma("foreign_keys = ON"),t.exec(N);let E=t.prepare("INSERT OR IGNORE INTO categories (slug, name, blurb, sort) VALUES (?,?,?,?)");return o.forEach((e,t)=>E.run(e.slug,e.name,e.blurb,t)),L.__csc_db=t,t}},1402:(e,t,E)=>{E.d(t,{AV:()=>a,oo:()=>i,pr:()=>s,vQ:()=>n});var r=E(9489),T=E(5462);class i extends Error{constructor(e,t,E){super(t),this.status=e,this.fields=E}}function a(e,t=200,E={}){return new Response(JSON.stringify(e),{status:t,headers:{"Content-Type":"application/json","Cache-Control":"no-store",...E}})}function s(e){return async(t,E)=>{try{return await e(t,E)}catch(e){if(e instanceof i)return a({error:e.message,fields:e.fields},e.status);if(e instanceof Error&&"SyntaxError"===e.name)return a({error:"The request was not valid JSON."},400);if(e instanceof r.j){let t={};for(let E of e.issues)t[E.path.join(".")||"_"]=E.message;return a({error:"Please check the highlighted fields.",fields:t},400)}return(0,T.H)("unhandled api error",e,{url:t.url,method:t.method}),a({error:"Something went wrong on our side. Please try again in a moment."},500)}}}function n(e,t){for(let E of(e.headers.get("cookie")||"").split(/;\s*/)){let e=E.indexOf("=");if(e>0&&E.slice(0,e)===t)return decodeURIComponent(E.slice(e+1))}}},5462:(e,t,E)=>{E.d(t,{H:()=>r});let r=(e,t,E={})=>(function(e,t,E={}){if(process.env.VITEST)return;let r=JSON.stringify({t:new Date().toISOString(),level:e,msg:t,...E});("error"===e?console.error:console.log)(r)})("error",e,{...E,err:t instanceof Error?{message:t.message,stack:t.stack}:String(t)})},9303:(e,t,E)=>{e.exports=E(517)}};var t=require("../../../../../webpack-runtime.js");t.C(e);var E=e=>t(t.s=e),r=t.X(0,[948,489,543],()=>E(2356));module.exports=r})();