"use strict";(()=>{var e={};e.id=440,e.ids=[440],e.modules={5890:e=>{e.exports=require("better-sqlite3")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},2048:e=>{e.exports=require("fs")},5315:e=>{e.exports=require("path")},9604:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>p,patchFetch:()=>c,requestAsyncStorage:()=>d,routeModule:()=>L,serverHooks:()=>u,staticGenerationAsyncStorage:()=>l});var E={};r.r(E),r.d(E,{POST:()=>o});var T=r(9303),a=r(8716),i=r(3131),s=r(1402),n=r(9178),N=r(196);let o=(0,s.pr)(async e=>{(0,n.kF)(e);let t=(await e.formData()).get("file");if(!(t instanceof File))throw new s.oo(400,"Choose an image to upload.");try{return(0,s.AV)({url:(0,N.id)(Buffer.from(await t.arrayBuffer()))},201)}catch(t){let e=t.message;if("too_large"===e)throw new s.oo(413,"Image is larger than 5 MB.");if("bad_type"===e)throw new s.oo(415,"Only PNG, JPEG or WebP images are accepted.");throw t}}),L=new T.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/admin/upload/route",pathname:"/api/admin/upload",filename:"route",bundlePath:"app/api/admin/upload/route"},resolvedPagePath:"/home/claude/csc/app/api/admin/upload/route.ts",nextConfigOutput:"standalone",userland:E}),{requestAsyncStorage:d,staticGenerationAsyncStorage:l,serverHooks:u}=L,p="/api/admin/upload/route";function c(){return(0,i.patchFetch)({serverHooks:u,staticGenerationAsyncStorage:l})}},9178:(e,t,r)=>{r.d(t,{B3:()=>o,Jg:()=>L,Kp:()=>p,Sp:()=>d,gf:()=>s,kF:()=>l,x4:()=>c});var E=r(4770),T=r.n(E),a=r(3652),i=r(1402);let s="csc_admin";function n(){let e=process.env.SESSION_SECRET;if(!e||e.length<32)throw Error("SESSION_SECRET must be set to at least 32 characters.");return e}let N=e=>Buffer.from(e).toString("base64url");function o(e,t=Date.now()){let r=N(JSON.stringify({id:e,exp:t+432e5})),E=T().createHmac("sha256",n()).update(r).digest("base64url");return`${r}.${E}`}function L(e,t=Date.now()){if(!e)return null;let[r,E]=e.split(".");if(!r||!E)return null;let i=T().createHmac("sha256",n()).update(r).digest("base64url"),s=Buffer.from(E),N=Buffer.from(i);if(s.length!==N.length||!T().timingSafeEqual(s,N))return null;try{let e=JSON.parse(Buffer.from(r,"base64url").toString());if("number"!=typeof e.id||"number"!=typeof e.exp||e.exp<t)return null;return(0,a.z)().prepare("SELECT id FROM admins WHERE id = ?").get(e.id)?{id:e.id}:null}catch{return null}}function d(e,t=!1){return`${s}=${t?"":e}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${t?0:43200}; Secure`}function l(e){let t=L((0,i.vQ)(e,s));if(!t)throw new i.oo(401,"Please sign in to continue.");if(!["GET","HEAD"].includes(e.method)){let t=e.headers.get("origin"),r=e.headers.get("host");if(t&&r&&new URL(t).host!==r)throw new i.oo(403,"Cross-origin request blocked.")}return t}let u=new Map;function p(e,t=Date.now()){let r=u.get(e);if(!r||r.reset<t){u.set(e,{n:1,reset:t+9e5});return}if(++r.n>8)throw new i.oo(429,"Too many sign-in attempts. Please wait 15 minutes.")}function c(e,t){let r=(0,a.z)().prepare("SELECT id, password_hash FROM admins WHERE email = ?").get(e.trim().toLowerCase()),E=function(e,t){let[r,E,a]=t.split("$");if("scrypt"!==r||!E||!a)return!1;let i=T().scryptSync(e,E,64),s=Buffer.from(a,"hex");return s.length===i.length&&T().timingSafeEqual(s,i)}(t,r?.password_hash??"scrypt$00$00");return r&&E?r.id:null}},3652:(e,t,r)=>{r.d(t,{z:()=>d});var E=r(5890),T=r.n(E),a=r(2048),i=r.n(a),s=r(5315),n=r.n(s);let N=`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, blurb TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  price_paise INTEGER NOT NULL CHECK (price_paise >= 0),
  gst_rate REAL, hsn TEXT NOT NULL DEFAULT '',
  lead_time_days INTEGER CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  engraving_enabled INTEGER NOT NULL DEFAULT 0, engraving_max INTEGER NOT NULL DEFAULT 20, engraving_fee_paise INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS product_categories (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, category_id)
);
CREATE TABLE IF NOT EXISTS variants (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  label TEXT NOT NULL, sku TEXT NOT NULL DEFAULT '', price_paise INTEGER CHECK (price_paise IS NULL OR price_paise >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0), sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL, alt TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_addons (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  addon_product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, addon_product_id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY, token TEXT UNIQUE NOT NULL, number TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',
  email TEXT NOT NULL, phone TEXT NOT NULL, name TEXT NOT NULL,
  ship_line1 TEXT NOT NULL, ship_line2 TEXT NOT NULL DEFAULT '', ship_city TEXT NOT NULL, ship_state TEXT NOT NULL,
  ship_pincode TEXT NOT NULL, ship_country TEXT NOT NULL DEFAULT 'India',
  items_total_paise INTEGER NOT NULL, discount_paise INTEGER NOT NULL DEFAULT 0, shipping_paise INTEGER NOT NULL,
  total_paise INTEGER NOT NULL, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  shipping_taxable_paise INTEGER NOT NULL DEFAULT 0, shipping_tax_paise INTEGER NOT NULL DEFAULT 0, shipping_gst_rate REAL NOT NULL DEFAULT 0,
  intra_state INTEGER NOT NULL DEFAULT 1,
  loyalty_enrolled INTEGER NOT NULL DEFAULT 0, points_redeemed INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0,
  payment_provider TEXT NOT NULL DEFAULT '', payment_ref TEXT NOT NULL DEFAULT '',
  shipping_provider TEXT NOT NULL DEFAULT '', awb TEXT NOT NULL DEFAULT '', tracking_url TEXT NOT NULL DEFAULT '',
  dispatch_by TEXT, visitor_id TEXT, notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')), paid_at TEXT, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, variant_id INTEGER, name TEXT NOT NULL, variant_label TEXT NOT NULL DEFAULT '', hsn TEXT NOT NULL DEFAULT '',
  gst_rate REAL NOT NULL, qty INTEGER NOT NULL, unit_paise INTEGER NOT NULL, gross_paise INTEGER NOT NULL,
  discount_paise INTEGER NOT NULL DEFAULT 0, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  engraving TEXT NOT NULL DEFAULT '', made_to_order INTEGER NOT NULL DEFAULT 0, stock_reserved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), number TEXT UNIQUE NOT NULL,
  issued_at TEXT NOT NULL, seller_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoice_counters (fy TEXT PRIMARY KEY, last INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS loyalty_members (email TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', points INTEGER NOT NULL DEFAULT 0, enrolled_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS loyalty_ledger (id INTEGER PRIMARY KEY, email TEXT NOT NULL, order_id INTEGER, delta INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, visitor_id TEXT NOT NULL, product_id INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('view','cart','purchase')), created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_events_visitor ON events(visitor_id);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
`,o=[{slug:"clay",name:"Air-Dry Clay & Polymer Clay",blurb:"Charms, trinket dishes and small sculpted pieces, shaped by hand."},{slug:"fiber-textile",name:"Fiber & Textile Art",blurb:"Chenille, thread and cloth worked into soft, tactile things."},{slug:"ceramics",name:"Handmade Ceramics",blurb:"Wheel-thrown and hand-built mugs, bowls and vases."},{slug:"home-decor",name:"Aesthetic Home Decor",blurb:"Quiet, colourful objects for shelves, walls and windowsills."},{slug:"accessories",name:"Personal Accessories",blurb:"Earrings, necklaces and little things to wear every day."},{slug:"wedding-events",name:"Wedding & Events",blurb:"Favours, table pieces and keepsakes made in batches."}],L=globalThis;function d(){if(L.__csc_db)return L.__csc_db;let e=process.env.DATABASE_PATH||"./data/store.db";":memory:"!==e&&i().mkdirSync(n().dirname(n().resolve(e)),{recursive:!0});let t=new(T())(e);t.pragma("journal_mode = WAL"),t.pragma("foreign_keys = ON"),t.exec(N);let r=t.prepare("INSERT OR IGNORE INTO categories (slug, name, blurb, sort) VALUES (?,?,?,?)");return o.forEach((e,t)=>r.run(e.slug,e.name,e.blurb,t)),L.__csc_db=t,t}},1402:(e,t,r)=>{r.d(t,{AV:()=>i,oo:()=>a,pr:()=>s,vQ:()=>n});var E=r(9489),T=r(5462);class a extends Error{constructor(e,t,r){super(t),this.status=e,this.fields=r}}function i(e,t=200,r={}){return new Response(JSON.stringify(e),{status:t,headers:{"Content-Type":"application/json","Cache-Control":"no-store",...r}})}function s(e){return async(t,r)=>{try{return await e(t,r)}catch(e){if(e instanceof a)return i({error:e.message,fields:e.fields},e.status);if(e instanceof Error&&"SyntaxError"===e.name)return i({error:"The request was not valid JSON."},400);if(e instanceof E.j){let t={};for(let r of e.issues)t[r.path.join(".")||"_"]=r.message;return i({error:"Please check the highlighted fields.",fields:t},400)}return(0,T.H)("unhandled api error",e,{url:t.url,method:t.method}),i({error:"Something went wrong on our side. Please try again in a moment."},500)}}}function n(e,t){for(let r of(e.headers.get("cookie")||"").split(/;\s*/)){let e=r.indexOf("=");if(e>0&&r.slice(0,e)===t)return decodeURIComponent(r.slice(e+1))}}},5462:(e,t,r)=>{r.d(t,{H:()=>E});let E=(e,t,r={})=>(function(e,t,r={}){if(process.env.VITEST)return;let E=JSON.stringify({t:new Date().toISOString(),level:e,msg:t,...r});("error"===e?console.error:console.log)(E)})("error",e,{...r,err:t instanceof Error?{message:t.message,stack:t.stack}:String(t)})},196:(e,t,r)=>{r.d(t,{id:()=>o,ws:()=>N});var E=r(2048),T=r.n(E),a=r(5315),i=r.n(a),s=r(4770),n=r.n(s);let N=()=>i().resolve(process.env.UPLOAD_DIR||"./data/uploads");function o(e){if(e.length>5242880)throw Error("too_large");let t=e.length>12&&e.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))?"png":e.length>3&&255===e[0]&&216===e[1]&&255===e[2]?"jpg":e.length>12&&"RIFF"===e.subarray(0,4).toString()&&"WEBP"===e.subarray(8,12).toString()?"webp":null;if(!t)throw Error("bad_type");T().mkdirSync(N(),{recursive:!0});let r=n().randomBytes(12).toString("hex")+"."+t;return T().writeFileSync(i().join(N(),r),e),`/api/media/${r}`}},9303:(e,t,r)=>{e.exports=r(517)}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),E=t.X(0,[948,489],()=>r(9604));module.exports=E})();