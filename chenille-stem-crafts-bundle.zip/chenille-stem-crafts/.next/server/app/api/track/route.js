"use strict";(()=>{var e={};e.id=234,e.ids=[234],e.modules={5890:e=>{e.exports=require("better-sqlite3")},399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4770:e=>{e.exports=require("crypto")},2048:e=>{e.exports=require("fs")},5315:e=>{e.exports=require("path")},9425:(e,T,E)=>{E.r(T),E.d(T,{originalPathname:()=>l,patchFetch:()=>u,requestAsyncStorage:()=>c,routeModule:()=>p,serverHooks:()=>R,staticGenerationAsyncStorage:()=>O});var t={};E.r(t),E.d(t,{POST:()=>U});var r=E(9303),N=E(8716),i=E(3131),a=E(4770),s=E.n(a),L=E(7543),n=E(1402),o=E(6475);let d=L.Ryn({productId:L.Rxh().int().positive(),type:L.KmV(["view","cart"])}),U=(0,n.pr)(async e=>{if((0,n.vQ)(e,o.$J))return(0,n.AV)({ok:!0,tracking:!1});let T=d.parse(await e.json()),E=(0,n.vQ)(e,o.vc),t={};return E&&/^[a-f0-9]{32}$/.test(E)||(E=s().randomBytes(16).toString("hex"),t["Set-Cookie"]=`${o.vc}=${E}; Path=/; Max-Age=7776000; SameSite=Lax; HttpOnly`),(0,o.Ny)(E,T.productId,T.type),(0,n.AV)({ok:!0,tracking:!0},200,t)}),p=new r.AppRouteRouteModule({definition:{kind:N.x.APP_ROUTE,page:"/api/track/route",pathname:"/api/track",filename:"route",bundlePath:"app/api/track/route"},resolvedPagePath:"/home/claude/csc/app/api/track/route.ts",nextConfigOutput:"standalone",userland:t}),{requestAsyncStorage:c,staticGenerationAsyncStorage:O,serverHooks:R}=p,l="/api/track/route";function u(){return(0,i.patchFetch)({serverHooks:R,staticGenerationAsyncStorage:O})}},6475:(e,T,E)=>{E.d(T,{$J:()=>N,Ny:()=>i,Tg:()=>a,vc:()=>r});var t=E(3652);let r="csc_vid",N="csc_nopers";function i(e,T,E){/^[a-f0-9]{16,64}$/.test(e)&&(0,t.z)().prepare("INSERT INTO events (visitor_id, product_id, type) VALUES (?,?,?)").run(e,T,E)}function a(e){(0,t.z)().prepare("DELETE FROM events WHERE visitor_id = ?").run(e)}},3652:(e,T,E)=>{E.d(T,{z:()=>d});var t=E(5890),r=E.n(t),N=E(2048),i=E.n(N),a=E(5315),s=E.n(a);let L=`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, blurb TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  price_paise INTEGER NOT NULL CHECK (price_paise >= 0),
  gst_rate REAL, hsn TEXT NOT NULL DEFAULT '',
  lead_time_days INTEGER CHECK (lead_time_days IS NULL OR lead_time_days >= 0),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  featured INTEGER NOT NULL DEFAULT 0,
  engraving_enabled INTEGER NOT NULL DEFAULT 0, engraving_max INTEGER NOT NULL DEFAULT 20, engraving_fee_paise INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS product_categories (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, category_id)
);
CREATE TABLE IF NOT EXISTS variants (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  label TEXT NOT NULL, sku TEXT NOT NULL DEFAULT '', price_paise INTEGER CHECK (price_paise IS NULL OR price_paise >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0), sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL, alt TEXT NOT NULL DEFAULT '', sort INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS product_addons (
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  addon_product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (product_id, addon_product_id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY, token TEXT UNIQUE NOT NULL, number TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment',
  email TEXT NOT NULL, phone TEXT NOT NULL, name TEXT NOT NULL,
  ship_line1 TEXT NOT NULL, ship_line2 TEXT NOT NULL DEFAULT '', ship_city TEXT NOT NULL, ship_state TEXT NOT NULL,
  ship_pincode TEXT NOT NULL, ship_country TEXT NOT NULL DEFAULT 'India',
  items_total_paise INTEGER NOT NULL, discount_paise INTEGER NOT NULL DEFAULT 0, shipping_paise INTEGER NOT NULL,
  total_paise INTEGER NOT NULL, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  shipping_taxable_paise INTEGER NOT NULL DEFAULT 0, shipping_tax_paise INTEGER NOT NULL DEFAULT 0, shipping_gst_rate REAL NOT NULL DEFAULT 0,
  intra_state INTEGER NOT NULL DEFAULT 1,
  loyalty_enrolled INTEGER NOT NULL DEFAULT 0, points_redeemed INTEGER NOT NULL DEFAULT 0, points_earned INTEGER NOT NULL DEFAULT 0,
  payment_provider TEXT NOT NULL DEFAULT '', payment_ref TEXT NOT NULL DEFAULT '',
  shipping_provider TEXT NOT NULL DEFAULT '', awb TEXT NOT NULL DEFAULT '', tracking_url TEXT NOT NULL DEFAULT '',
  dispatch_by TEXT, visitor_id TEXT, notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')), paid_at TEXT, expires_at TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER, variant_id INTEGER, name TEXT NOT NULL, variant_label TEXT NOT NULL DEFAULT '', hsn TEXT NOT NULL DEFAULT '',
  gst_rate REAL NOT NULL, qty INTEGER NOT NULL, unit_paise INTEGER NOT NULL, gross_paise INTEGER NOT NULL,
  discount_paise INTEGER NOT NULL DEFAULT 0, taxable_paise INTEGER NOT NULL, cgst_paise INTEGER NOT NULL, sgst_paise INTEGER NOT NULL, igst_paise INTEGER NOT NULL,
  engraving TEXT NOT NULL DEFAULT '', made_to_order INTEGER NOT NULL DEFAULT 0, stock_reserved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY, order_id INTEGER UNIQUE NOT NULL REFERENCES orders(id), number TEXT UNIQUE NOT NULL,
  issued_at TEXT NOT NULL, seller_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invoice_counters (fy TEXT PRIMARY KEY, last INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS loyalty_members (email TEXT PRIMARY KEY, name TEXT NOT NULL DEFAULT '', points INTEGER NOT NULL DEFAULT 0, enrolled_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS loyalty_ledger (id INTEGER PRIMARY KEY, email TEXT NOT NULL, order_id INTEGER, delta INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, visitor_id TEXT NOT NULL, product_id INTEGER NOT NULL, type TEXT NOT NULL CHECK (type IN ('view','cart','purchase')), created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS idx_events_visitor ON events(visitor_id);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')));
`,n=[{slug:"clay",name:"Air-Dry Clay & Polymer Clay",blurb:"Charms, trinket dishes and small sculpted pieces, shaped by hand."},{slug:"fiber-textile",name:"Fiber & Textile Art",blurb:"Chenille, thread and cloth worked into soft, tactile things."},{slug:"ceramics",name:"Handmade Ceramics",blurb:"Wheel-thrown and hand-built mugs, bowls and vases."},{slug:"home-decor",name:"Aesthetic Home Decor",blurb:"Quiet, colourful objects for shelves, walls and windowsills."},{slug:"accessories",name:"Personal Accessories",blurb:"Earrings, necklaces and little things to wear every day."},{slug:"wedding-events",name:"Wedding & Events",blurb:"Favours, table pieces and keepsakes made in batches."}],o=globalThis;function d(){if(o.__csc_db)return o.__csc_db;let e=process.env.DATABASE_PATH||"./data/store.db";":memory:"!==e&&i().mkdirSync(s().dirname(s().resolve(e)),{recursive:!0});let T=new(r())(e);T.pragma("journal_mode = WAL"),T.pragma("foreign_keys = ON"),T.exec(L);let E=T.prepare("INSERT OR IGNORE INTO categories (slug, name, blurb, sort) VALUES (?,?,?,?)");return n.forEach((e,T)=>E.run(e.slug,e.name,e.blurb,T)),o.__csc_db=T,T}},1402:(e,T,E)=>{E.d(T,{AV:()=>i,oo:()=>N,pr:()=>a,vQ:()=>s});var t=E(9489),r=E(5462);class N extends Error{constructor(e,T,E){super(T),this.status=e,this.fields=E}}function i(e,T=200,E={}){return new Response(JSON.stringify(e),{status:T,headers:{"Content-Type":"application/json","Cache-Control":"no-store",...E}})}function a(e){return async(T,E)=>{try{return await e(T,E)}catch(e){if(e instanceof N)return i({error:e.message,fields:e.fields},e.status);if(e instanceof Error&&"SyntaxError"===e.name)return i({error:"The request was not valid JSON."},400);if(e instanceof t.j){let T={};for(let E of e.issues)T[E.path.join(".")||"_"]=E.message;return i({error:"Please check the highlighted fields.",fields:T},400)}return(0,r.H)("unhandled api error",e,{url:T.url,method:T.method}),i({error:"Something went wrong on our side. Please try again in a moment."},500)}}}function s(e,T){for(let E of(e.headers.get("cookie")||"").split(/;\s*/)){let e=E.indexOf("=");if(e>0&&E.slice(0,e)===T)return decodeURIComponent(E.slice(e+1))}}},5462:(e,T,E)=>{E.d(T,{H:()=>t});let t=(e,T,E={})=>(function(e,T,E={}){if(process.env.VITEST)return;let t=JSON.stringify({t:new Date().toISOString(),level:e,msg:T,...E});("error"===e?console.error:console.log)(t)})("error",e,{...E,err:T instanceof Error?{message:T.message,stack:T.stack}:String(T)})},9303:(e,T,E)=>{e.exports=E(517)}};var T=require("../../../webpack-runtime.js");T.C(e);var E=e=>T(T.s=e),t=T.X(0,[948,489,543],()=>E(9425));module.exports=t})();