#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "Missing .env. Copy .env.example to .env and fill it in."; exit 1; }
set -a; . ./.env; set +a
exec node seed.cjs
