import { z } from 'zod';
import { handle, json, HttpError } from '@/lib/http';
import { requireAdmin } from '@/lib/auth';
import { getDb } from '@/lib/db';

const body = z.object({ status: z.enum(['paid', 'shipped', 'delivered', 'cancelled']).optional(), awb: z.string().trim().max(60).optional(), trackingUrl: z.string().trim().url().max(300).or(z.literal('')).optional() });
export const PATCH = handle(async (req, c) => {
  requireAdmin(req);
  const id = Number(c?.params?.id); const b = body.parse(await req.json());
  const o = getDb().prepare('SELECT status FROM orders WHERE id=?').get(id) as { status: string } | undefined;
  if (!o) throw new HttpError(404, 'Order not found.');
  if (b.status && ['pending_payment', 'expired', 'payment_failed'].includes(o.status)) throw new HttpError(409, 'This order has not been paid, so its status cannot be changed.');
  getDb().prepare('UPDATE orders SET status=COALESCE(?,status), awb=COALESCE(?,awb), tracking_url=COALESCE(?,tracking_url) WHERE id=?').run(b.status ?? null, b.awb ?? null, b.trackingUrl ?? null, id);
  return json({ ok: true });
});
