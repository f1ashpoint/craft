import { z } from 'zod';
import { handle, json, HttpError } from '@/lib/http';
import { requireAdmin } from '@/lib/auth';
import { productInput, saveProduct, setArchived, deleteProduct, getProductById } from '@/lib/catalog';

const idOf = (c: any) => { const n = Number(c?.params?.id); if (!Number.isInteger(n)) throw new HttpError(400, 'Bad product id'); return n; };
export const PUT = handle(async (req, c) => {
  requireAdmin(req); const id = idOf(c);
  if (!getProductById(id)) throw new HttpError(404, 'Product not found.');
  saveProduct(productInput.parse(await req.json()), id);
  return json({ id });
});
export const PATCH = handle(async (req, c) => {
  requireAdmin(req); const id = idOf(c);
  const { archived } = z.object({ archived: z.boolean() }).parse(await req.json());
  if (!setArchived(id, archived)) throw new HttpError(404, 'Product not found.');
  return json({ id, archived });
});
export const DELETE = handle(async (req, c) => {
  requireAdmin(req);
  if (!deleteProduct(idOf(c))) throw new HttpError(404, 'Product not found.');
  return json({ ok: true });
});
