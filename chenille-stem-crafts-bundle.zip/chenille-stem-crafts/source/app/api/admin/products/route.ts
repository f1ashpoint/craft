import { handle, json } from '@/lib/http';
import { requireAdmin } from '@/lib/auth';
import { listProducts, productInput, saveProduct } from '@/lib/catalog';

export const GET = handle(async (req) => { requireAdmin(req); return json({ products: listProducts({ includeArchived: true }) }); });
export const POST = handle(async (req) => {
  requireAdmin(req);
  const id = saveProduct(productInput.parse(await req.json()));
  return json({ id }, 201);
});
