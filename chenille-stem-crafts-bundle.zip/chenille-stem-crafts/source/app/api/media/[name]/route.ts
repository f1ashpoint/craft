import fs from 'fs';
import path from 'path';
import { uploadDir } from '@/lib/media';
const types: Record<string, string> = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp' };
export async function GET(_r: Request, { params }: { params: { name: string } }) {
  if (!/^[a-f0-9]{24}\.(png|jpg|webp)$/.test(params.name)) return new Response('Not found', { status: 404 });
  try {
    const buf = fs.readFileSync(path.join(uploadDir(), params.name));
    return new Response(new Uint8Array(buf), { headers: { 'Content-Type': types[params.name.split('.')[1]], 'Cache-Control': 'public, max-age=31536000, immutable' } });
  } catch { return new Response('Not found', { status: 404 }); }
}
