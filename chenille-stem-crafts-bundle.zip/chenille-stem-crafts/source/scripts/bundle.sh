#!/usr/bin/env bash
# Builds the production bundle and zips it: dist/chenille-stem-crafts-bundle.zip
set -euo pipefail
cd "$(dirname "$0")/.."
NAME=chenille-stem-crafts
OUT=release/$NAME
rm -rf release dist && mkdir -p "$OUT" dist

node scripts/gen-art.js
NODE_ENV=production npx next build

# 1. Production server (Next standalone output) + static assets
cp -r .next/standalone/. "$OUT/"
mkdir -p "$OUT/.next" && cp -r .next/static "$OUT/.next/static"
cp -r public "$OUT/public"
rm -rf "$OUT/data" "$OUT/.env"
mkdir -p "$OUT/data/uploads"

# 2. Seed script as a single self-contained file (uses the better-sqlite3 inside ./node_modules)
npx esbuild scripts/seed.ts --bundle --platform=node --format=cjs --target=node20 --external:better-sqlite3 --outfile="$OUT/seed.cjs" --log-level=warning

# 3. Config template, scripts, docs
cp .env.example "$OUT/.env.example"
cp README.md "$OUT/README.md"
cat > "$OUT/start.sh" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "Missing .env. Copy .env.example to .env and fill it in."; exit 1; }
set -a; . ./.env; set +a
export NODE_ENV=production
export HOSTNAME="${BIND_HOST:-0.0.0.0}"   # Next.js reads HOSTNAME to choose the bind address
export PORT="${PORT:-3000}"
exec node server.js
EOS
cat > "$OUT/seed.sh" <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "Missing .env. Copy .env.example to .env and fill it in."; exit 1; }
set -a; . ./.env; set +a
exec node seed.cjs
EOS
chmod +x "$OUT/start.sh" "$OUT/seed.sh"

# 4. Full source (no node_modules, build output, secrets or data) so the owner can rebuild and run the tests
mkdir -p "$OUT/source"
tar --exclude=node_modules --exclude=.next --exclude=release --exclude=dist --exclude=data --exclude=.env --exclude='*.tsbuildinfo' --exclude=next-env.d.ts -cf - . | tar -xf - -C "$OUT/source"

(cd release && zip -qr "../dist/$NAME-bundle.zip" "$NAME")
ls -lh dist/
