#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] || { echo "Missing .env. Copy .env.example to .env and fill it in."; exit 1; }
set -a; . ./.env; set +a
export NODE_ENV=production
export HOSTNAME="${BIND_HOST:-0.0.0.0}"   # Next.js reads HOSTNAME to choose the bind address
export PORT="${PORT:-3000}"
exec node server.js
